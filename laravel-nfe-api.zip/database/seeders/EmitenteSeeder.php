<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class EmitenteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Emitente::factory()->count(1)->forUser([ 'name' => 'Millennium', ])->create();

    }
}
